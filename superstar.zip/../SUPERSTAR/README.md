# SUPERSTAR.exe

A mobile-friendly, browser-based cinematic decision story built with plain HTML, CSS, and JavaScript modules.

## Run the game

Because the game loads story JSON with `fetch()` and uses ES modules, do **not** open `index.html` directly as a `file://` URL. Run a local static server instead.

### Android (Termux)
1. Install Python if needed: `pkg install python`
2. Change directory to the extracted `SUPERSTAR` folder.
3. Run: `python -m http.server 8000`
4. Open `http://127.0.0.1:8000` in Chrome on the same device.

### Windows / macOS / Linux
Open a terminal in the extracted `SUPERSTAR` folder and run:

```bash
python -m http.server 8000
```

Then visit `http://127.0.0.1:8000` in your browser.

## Current sample story

- **New Audition** starts at `intro_001`.
- Finish Liam's opening dialogue and the three choices appear while his dialogue remains visible.
- Any opening choice leads to `audition_001`.
- The audition narration advances to a sample choice, which currently returns to the opening scene. This is a deliberate placeholder because the supplied source archive does not yet include the rest of the story.

## Persistence

The game uses IndexedDB for the active save. Continue Career resumes from the saved scene and block. Export/import save controls are available in Settings.

## Validation and fixes in this revision

- Fixed a JavaScript syntax error in the developer scene validator. The invalid `await` prevented the entire app module from loading, which meant **New Audition had no working click handler**.
- Kept the speaker's dialogue panel visible when the choice block renders, so choices are presented alongside the dialogue rather than replacing it.
- Made character-image URL comparison robust when the browser resolves relative asset paths.
- Added the missing `audition_001` destination referenced by all three opening choices.
- Connected the developer validator, save button, and main-menu Settings button.
- Rendered choice text with `textContent` to avoid treating story text as HTML.

## Project structure

- `index.html` – app markup and overlays
- `css/` – cinematic interface styles and animations
- `js/` – story engine, choices, IndexedDB persistence, audio, UI
- `data/` – story, characters, and ending definitions
- `assets/images/` – included background and character images

The opening story is still sample content. Replace the placeholder scene and its choice in `data/story.json` as you build the full narrative.


## Cinematic audition chapter update
- Cassandra's transparent character cutout is in `assets/images/cassandra-cutout.png`.
- The dialogue panel measures each complete line of dialogue before the typewriter animation starts, preventing the card from growing as characters appear.
- Tap after reading a dialogue to advance; choices then fade in sequentially. Tap a choice to follow its branch.
- The included test story covers the morning rush, transport decision, waiting-room mishap, audition performance, and follow-up message.
- Run from a local web server (not `file://`) because the app loads story JSON using `fetch`.

## Latest mobile UI corrections

- Dialogue text is explicitly layered above the holographic panel's translucent fill, fixing the invisible-text issue.
- Cassandra's portrait is positioned in the upper portion of the screen (roughly 12–47% of viewport height) and fades out along its lower edge.
- The dialogue panel begins around 34% viewport height; choices begin around 59%, keeping the lower choice stack within the intended screen area on typical phone displays.
- Dialogue and choices use highly translucent glass fills so the scene remains visible behind them.
- Choice buttons now render one text line only; optional secondary descriptions have been removed from the story data and renderer.
- Added a local SVG SYSTEM.exe avatar to remove a missing character portrait asset.

The UI has been checked with JavaScript syntax, JSON/story-reference, and asset-path validations. Automated browser navigation is restricted in the current environment, so a full live browser playthrough could not be completed here.


## UI and scene improvements in this package

- Dialogue and choice panels use approximately 30% opaque dark fills; the borders are intentionally more opaque for contrast.
- Choices now flow directly beneath the dialogue with a two-line visual gap instead of a fixed screen coordinate.
- The bottom-center “Tap to continue” cue has three animated rings. Tapping any open area of the story screen advances dialogue; choice buttons and HUD controls retain their own actions.
- Scene backgrounds cross-fade. The bundled scene-specific backgrounds are `bedroom_dawn.jpg`, `city_morning.jpg`, `audition_lobby.jpg`, and `audition_stage.jpg`, alongside the original images.
- Cassandra appears on the left. Other speakers appear on the right, with the dialogue panel's clipped corner shape reversed. Only one character portrait is shown at a time. `data/characters.json` controls portrait selection, so replace `system.portrait` later when you have a final SYSTEM.exe illustration.
- Saving remains automatic and silent; no “Saved successfully” toast is shown.
- A full-screen secret-agent terminal runs before a new game. It types each line character-by-character, pauses between output lines, displays a blinking cursor, and uses passcode `1012`. Continue Career skips the intro terminal.
- Achievement and notification popups appear at the top-right and disappear automatically.

## Adding an achievement or notification

Add a block inside a scene's `blocks` array in `data/story.json`:

```json
{
  "id": "manager_hired_achievement",
  "type": "achievement",
  "achievementId": "manager_hired",
  "title": "THE MANAGER HIRED YOU",
  "message": "Good job! Your first professional opportunity is secured."
}
```

Achievement blocks unlock the achievement, show the top-right toast, save silently, and immediately continue to the next story block. Use `"type": "notification"` for a temporary popup that does not unlock an achievement:

```json
{
  "id": "contract_notification",
  "type": "notification",
  "title": "NEW CONTRACT",
  "message": "A producer has sent a contract for review."
}
```

Keep each `id` unique within the story, and place these blocks wherever the event should trigger. The toast duration defaults to five seconds and can be changed by passing a third argument to `eventManager.showNotification(title, message, duration)` in `js/events.js`.


## Audio assets and scene music

Copy your four existing audio files into `assets/audios/` using these exact names: `keypress-014.wav`, `fx-dialogue.mp3`, `bg-andriih-soft.mp3`, `bg-leberch-soft.mp3`, and `bg-atlasaudio-soft.mp3`. The code plays `fx-dialogue.mp3` once when each dialogue block begins and plays `keypress-014.wav` once when the player clicks an option. No sound plays for individual typewriter characters. A scene can start or change music by adding a `"music": "assets/audios/filename.mp3"` property to that scene in `data/story.json`. Scenes without a `music` property deliberately continue the current track. Track changes cross-fade, and completed tracks fade down and restart with a fade-in.

The supplied ZIP used for this update does not include the imported audio files themselves, so the code references them but they must be copied from your existing project into `assets/audios/`. Font Awesome is loaded from its CDN for the settings cog icon; an internet connection is needed to fetch that icon stylesheet.


### Dialogue-specific dramatic sound effects

Add an optional `audio` property to any `type: "dialogue"` block in `data/story.json` to play a one-shot dramatic sound from `assets/audios/`. Example:

```json
{
  "id": "footsteps",
  "type": "dialogue",
  "speaker": "system",
  "content": "Footsteps approach...",
  "audio": "assets/audios/fx-footsteps.mp3"
}
```

- The sound starts once when that dialogue appears and never loops automatically.
- If consecutive dialogue blocks use the same exact `audio` path, playback continues without restarting or a transition gap.
- A dialogue block with no `audio` property stops the previous dramatic sound immediately. A different path stops the old sound and starts the new one immediately.
- Returning to a dialogue after its previous sound has been stopped plays it again. Revisiting the same path while its sound is still the active continuous sound does not restart it.
- Dramatic sounds use the SFX volume setting and do not affect background music or the per-dialogue `fx-dialogue.mp3` cue.

Currently assigned in the story:
- `cab_outcome` / `cab_result`: `assets/audios/fx-car-starts-driving.mp3`
- `waiting_room` / `footsteps`: `assets/audios/fx-footsteps.mp3`

Place both files in `SUPERSTAR/assets/audios/`. They are not bundled in this ZIP; retain/copy your own audio assets when replacing the project.
