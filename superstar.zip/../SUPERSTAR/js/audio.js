// Audio manager: sampled keypress SFX and persistent, cross-faded background music.
export const audioManager = {
    bgm: null,
    currentMusicPath: null,
    volumeMusic: 0.5,
    volumeSfx: 0.7,
    audioCtx: null,
    keypressPath: 'assets/audios/keypress-014.wav',
    dialoguePath: 'assets/audios/fx-dialogue.mp3',
    keypressSample: null,
    dialogueSample: null,
    dialogueAmbience: null,
    dialogueAmbiencePath: null,
    musicFadeTimer: null,
    musicGeneration: 0,

    init() {
        this.keypressSample = new Audio(this.keypressPath);
        this.keypressSample.preload = 'auto';
        this.dialogueSample = new Audio(this.dialoguePath);
        this.dialogueSample.preload = 'auto';
        const musicSlider = document.getElementById('volume-music');
        const sfxSlider = document.getElementById('volume-sfx');
        if (musicSlider) {
            this.volumeMusic = Number(musicSlider.value);
            musicSlider.addEventListener('input', (e) => {
                this.volumeMusic = Number(e.target.value);
                if (this.bgm && !this.bgm.paused) this.bgm.volume = this.volumeMusic;
            });
        }
        if (sfxSlider) {
            this.volumeSfx = Number(sfxSlider.value);
            sfxSlider.addEventListener('input', (e) => {
                this.volumeSfx = Number(e.target.value);
                if (this.dialogueAmbience) this.dialogueAmbience.volume = this.volumeSfx;
            });
        }
        // Browsers permit audio playback after the player's first gesture.
        const unlock = async () => {
            if (this.bgm && this.bgm.paused && this.currentMusicPath) {
                try { await this.bgm.play(); } catch (_) { /* browser may still block autoplay */ }
            }
            document.removeEventListener('pointerdown', unlock);
            document.removeEventListener('keydown', unlock);
        };
        document.addEventListener('pointerdown', unlock, { once: true });
        document.addEventListener('keydown', unlock, { once: true });
    },

    // Play the dialogue sound once when a dialogue block begins.
    playDialogueSound() {
        if (this.volumeSfx <= 0) return;
        try {
            const sample = this.dialogueSample ? this.dialogueSample.cloneNode(true) : new Audio(this.dialoguePath);
            sample.currentTime = 0;
            sample.volume = Math.max(0, Math.min(1, this.volumeSfx));
            sample.play().catch(() => {});
        } catch (_) { /* optional dialogue SFX must never break the story */ }
    },

    // Play the keypress sample once per option click, not during typewriter animation.
    playTypeClick() {
        if (this.volumeSfx <= 0) return;
        try {
            const sample = this.keypressSample ? this.keypressSample.cloneNode(true) : new Audio(this.keypressPath);
            sample.currentTime = 0;
            sample.volume = Math.max(0, Math.min(1, this.volumeSfx));
            sample.play().catch(() => {});
        } catch (_) { /* missing optional SFX should never break the story */ }
    },

    // Play a scene/dialogue-specific dramatic sound once. Consecutive dialogue
    // blocks using the exact same path share one uninterrupted playback. A block
    // without audio stops it immediately; an ended sound is not auto-replayed.
    setDialogueAmbience(path) {
        const nextPath = typeof path === 'string' ? path.trim() : '';

        if (nextPath && nextPath === this.dialogueAmbiencePath && this.dialogueAmbience) return;

        if (this.dialogueAmbience) {
            this.dialogueAmbience.pause();
            this.dialogueAmbience.currentTime = 0;
            this.dialogueAmbience = null;
        }
        this.dialogueAmbiencePath = nextPath || null;

        if (!nextPath || this.volumeSfx <= 0) return;

        try {
            const sound = new Audio(nextPath);
            sound.preload = 'auto';
            sound.loop = false;
            sound.volume = Math.max(0, Math.min(1, this.volumeSfx));
            sound.addEventListener('error', () => {
                console.warn(`Dialogue sound unavailable: ${nextPath}`);
            }, { once: true });
            this.dialogueAmbience = sound;
            sound.play().catch(() => {});
        } catch (_) {
            // Optional dramatic audio must never interrupt story progression.
        }
    },

    async fadeAudio(audio, targetVolume, duration = 1800, generation = null) {
        if (!audio) return;
        if (this.musicFadeTimer) cancelAnimationFrame(this.musicFadeTimer);
        const startVolume = Number.isFinite(audio.volume) ? audio.volume : 0;
        const start = performance.now();
        return new Promise(resolve => {
            const step = (now) => {
                if (generation !== null && generation !== this.musicGeneration) { resolve(); return; }
                const progress = Math.min(1, (now - start) / Math.max(1, duration));
                audio.volume = Math.max(0, Math.min(1, startVolume + (targetVolume - startVolume) * progress));
                if (progress < 1) this.musicFadeTimer = requestAnimationFrame(step);
                else { this.musicFadeTimer = null; resolve(); }
            };
            this.musicFadeTimer = requestAnimationFrame(step);
        });
    },

    // No music path means keep the current track playing. A different path cross-fades.
    async setSceneMusic(path) {
        if (!path || path === this.currentMusicPath) return;
        const generation = ++this.musicGeneration;
        const previous = this.bgm;
        if (previous) {
            await this.fadeAudio(previous, 0, 2200, generation);
            if (generation !== this.musicGeneration) return;
            previous.pause();
            previous.currentTime = 0;
        }
        this.currentMusicPath = path;
        const next = new Audio(path);
        next.loop = false; // custom end handler fades and restarts it smoothly
        next.preload = 'auto';
        next.volume = 0;
        this.bgm = next;
        next.addEventListener('ended', async () => {
            if (this.bgm !== next || !this.currentMusicPath) return;
            const loopGeneration = this.musicGeneration;
            await this.fadeAudio(next, 0, 1200, loopGeneration);
            if (this.bgm !== next || loopGeneration !== this.musicGeneration) return;
            try {
                next.currentTime = 0;
                next.volume = 0;
                await next.play();
                this.fadeAudio(next, this.volumeMusic, 1800, loopGeneration);
            } catch (_) { /* playback can be blocked until the next user gesture */ }
        });
        next.addEventListener('error', () => console.warn(`Background music unavailable: ${path}`), { once: true });
        try {
            await next.play();
            await this.fadeAudio(next, this.volumeMusic, 2600, generation);
        } catch (_) {
            // Remember the selected track; a later user gesture can unlock it.
        }
    },

    playBGM(mood) { console.log(`BGM mood: ${mood}`); },
    playSFX(type) { console.log(`SFX: ${type}`); }
};
