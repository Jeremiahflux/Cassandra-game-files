// Application Bootstrapper
import { gameEngine } from './engine.js';
import { db } from './database.js';
import { playerState } from './state.js';
import { uiManager } from './ui.js';
import { audioManager } from './audio.js';
import { storyLoader } from './story.js';

document.addEventListener('DOMContentLoaded', async () => {
    uiManager.init();
    audioManager.init();

    const continueBtn = document.getElementById('btn-continue');
    const newGameBtn = document.getElementById('btn-new-game');
    const hardResetBtn = document.getElementById('btn-hard-reset');
    const exportBtn = document.getElementById('btn-export-save');
    const importBtn = document.getElementById('btn-import-save');
    const importFileInput = document.getElementById('import-file-input');

    // Check for existing save
    try {
        const savedGame = await db.loadGame();
        if (savedGame) {
            continueBtn.classList.remove('hidden');
            continueBtn.addEventListener('click', () => {
                playerState.deserialize(savedGame.playerState);
                gameEngine.start(savedGame.sceneId, savedGame.blockIndex || 0, false);
            });
        }
    } catch (err) {
        console.error("Error loading save game:", err);
    }

    newGameBtn.addEventListener('click', async () => {
        newGameBtn.disabled = true;
        const originalLabel = newGameBtn.textContent;
        newGameBtn.textContent = 'Starting...';
        try {
            // A blocked/unavailable IndexedDB must not prevent a new career from starting.
            try {
                await db.clearSave();
            } catch (saveError) {
                console.warn('Could not clear the previous save; starting without clearing it:', saveError);
            }
            playerState.reset();
            await gameEngine.start('intro_001', 0, true);
        } catch (err) {
            console.error('Could not start a new game:', err);
            alert(`The game could not start.\n\n${err?.message || err}\n\nOpen the game through a local web server, not directly as an index.html file.`);
        } finally {
            newGameBtn.disabled = false;
            newGameBtn.textContent = originalLabel;
        }
    });

    hardResetBtn.addEventListener('click', async () => {
        if (confirm("Are you sure you want to reset all career progress?")) {
            await db.clearSave();
            location.reload();
        }
    });

    exportBtn.addEventListener('click', async () => {
        const json = await db.exportSaveJSON();
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'superstar_save.json';
        a.click();
    });

    importBtn.addEventListener('click', () => importFileInput.click());
    importFileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (file) {
            const text = await file.text();
            const success = await db.importSaveJSON(text);
            if (success) {
                alert("Save imported successfully!");
                location.reload();
            } else {
                alert("Failed to import save file.");
            }
        }
    });


    // Wire up visible controls that were previously present but inactive.
    document.getElementById('btn-menu-settings').addEventListener('click', () => {
        uiManager.toggleModal('settings-modal', true);
    });
    document.getElementById('btn-save').addEventListener('click', () => gameEngine.autoSave());
    document.getElementById('dev-validate-btn').addEventListener('click', async () => {
        const log = document.getElementById('dev-log');
        if (!storyLoader.storyData) await storyLoader.init();
        const broken = storyLoader.validate();
        log.textContent = broken.length
            ? `Found ${broken.length} broken scene reference(s):\n${broken.join('\n')}`
            : 'Validation passed. All referenced scenes exist.';

    });

    // Developer mode shortcut (Triple click HUD title)
    let clickCount = 0;
    document.getElementById('hud-scene-title').addEventListener('click', () => {
        clickCount++;
        if (clickCount >= 3) {
            document.getElementById('btn-dev').classList.remove('hidden');
            alert("🛠️ Developer Mode Unlocked!");
            clickCount = 0;
        }
    });

    document.getElementById('dev-jump-btn').addEventListener('click', () => {
        const targetScene = document.getElementById('dev-scene-input').value.trim();
        if (targetScene) {
            uiManager.toggleModal('dev-modal', false);
            gameEngine.loadScene(targetScene);
        }
    });


});