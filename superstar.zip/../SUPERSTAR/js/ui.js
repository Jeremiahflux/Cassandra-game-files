// UI Renderer & Modal Controller
export const uiManager = {
    init() {
        // Modal toggles
        document.getElementById('btn-settings').addEventListener('click', () => this.toggleModal('settings-modal', true));
        document.getElementById('btn-dev').addEventListener('click', () => this.toggleModal('dev-modal', true));

        document.querySelectorAll('.close-modal-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const modalId = e.target.getAttribute('data-modal');
                this.toggleModal(modalId, false);
            });
        });
    },

    toggleModal(modalId, show) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.toggle('hidden', !show);
        }
    },

    showSaveIndicator(status) {
        const indicator = document.getElementById('save-indicator');
        indicator.textContent = status === 'saving' ? 'Saving progress...' : 'Saved successfully.';
        indicator.classList.remove('hidden');
        setTimeout(() => indicator.classList.add('hidden'), 2000);
    }
};