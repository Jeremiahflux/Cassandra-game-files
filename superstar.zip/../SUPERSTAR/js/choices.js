// Choice Evaluation & Consequences Processor
import { playerState } from './state.js';

export const choiceHandler = {
    processChoice(choiceOption, engineCallback) {
        if (choiceOption.effects) {
            for (const effect of choiceOption.effects) {
                if (effect.stat) {
                    playerState.updateStats({ [effect.stat]: effect.value });
                }
                if (effect.flag) {
                    playerState.setFlag(effect.flag, effect.value !== undefined ? effect.value : true);
                }
            }
        }
        if (choiceOption.nextScene) {
            engineCallback(choiceOption.nextScene);
        }
    }
};