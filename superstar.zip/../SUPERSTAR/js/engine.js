// Core Narrative Engine with Full Character Sprites & Custom UI
import { storyLoader } from './story.js';
import { playerState } from './state.js';
import { mediaManager } from './media.js';
import { audioManager } from './audio.js';
import { choiceHandler } from './choices.js';
import { eventManager } from './events.js';
import { db } from './database.js';
import { uiManager } from './ui.js';

export const gameEngine = {
    currentSceneId: null,
    currentBlockIndex: 0,
    sceneData: null,
    activeTypingTimeout: null,
    isTyping: false,
    currentFullText: '',
    currentTypingElement: null,

    async start(sceneId = 'intro_001', blockIndex = 0, showBoot = false) {
        // Load the story before hiding the menu so a fetch/path error never leaves a blank screen.
        const loaded = await storyLoader.init();
        if (!loaded) {
            throw new Error('Story files could not be loaded. Run this project from a local web server instead of opening index.html directly.');
        }
        document.getElementById('main-menu').classList.add('hidden');
        this.setupScreenTapListener();
        if (showBoot) {
            this.runTerminalBoot([
                'BOOTING SYSTEM... INITIALIZING...',
                'Loading secret hashes...',
                'Switching to secure line...',
                'Securing system...',
                'System Secured!',
                'Loading system commands...',
                'Welcome, Cassie!'
            ], () => this.loadScene(sceneId, blockIndex));
        } else {
            document.getElementById('terminal-screen').classList.add('hidden');
            this.loadScene(sceneId, blockIndex);
        }
    },

    setupScreenTapListener() {
        const nextButton = document.getElementById('btn-next-block');
        nextButton.onclick = (e) => { e.stopPropagation(); this.handleUserTap(); };
        const viewport = document.getElementById('story-viewport');
        viewport.onclick = (e) => {
            if (e.target.closest('.game-hud') || e.target.closest('.choice-btn') || e.target.closest('.modal-overlay')) {
                return;
            }
            this.handleUserTap();
        };
    },

    handleUserTap() {
        if (this.isTyping && this.currentTypingElement) {
            clearTimeout(this.activeTypingTimeout);
            this.currentTypingElement.textContent = this.currentFullText;
            this.currentTypingElement.classList.remove('typing-cursor');
            this.isTyping = false;
            document.getElementById('btn-next-block').classList.remove('hidden');
            return;
        }

        const block = this.sceneData?.blocks[this.currentBlockIndex];
        if (block && block.type !== 'choice') {
            this.currentBlockIndex++;
            this.renderCurrentBlock();
        }
    },

    async loadScene(sceneId, blockIndex = 0) {
        this.currentSceneId = sceneId;
        this.currentBlockIndex = Math.max(0, Number(blockIndex) || 0);
        this.sceneData = storyLoader.getScene(sceneId);

        if (!this.sceneData) {
            console.error(`❌ Scene not found: ${sceneId}`);
            return;
        }

        // Apply Explicit Camera Direction & Background from JSON
        mediaManager.setBackground(this.sceneData.background, this.sceneData.camera || 'none');
        // A missing music property intentionally leaves the previous scene's track running.
        audioManager.setSceneMusic(this.sceneData.music || null);

        document.getElementById('hud-scene-title').textContent = this.sceneData.title || '';

        if (this.sceneData.terminalBoot) {
            this.runTerminalBoot(this.sceneData.terminalBoot, () => {
                this.renderCurrentBlock();
            });
        } else {
            this.renderCurrentBlock();
        }

        this.autoSave();
    },

    renderCurrentBlock() {
        const contentArea = document.getElementById('narrative-container');
        const choicesContainer = document.getElementById('choices-container');
        const characterBox = document.getElementById('character-box');
        const nextBtn = document.getElementById('btn-next-block');
        const stage = document.getElementById('character-stage');

        if (this.activeTypingTimeout) {
            clearTimeout(this.activeTypingTimeout);
        }

        contentArea.innerHTML = '';
        choicesContainer.innerHTML = '';
        nextBtn.classList.add('hidden');
        this.isTyping = false;

        if (!this.sceneData || !this.sceneData.blocks) return;
        const block = this.sceneData.blocks[this.currentBlockIndex];
        // Keep the most recent speaker dialogue visible beside the choices, matching
        // the intended visual-novel layout. Other block types start with a clean box.
        if (!block || block.type !== 'choice') {
            characterBox.classList.add('hidden');
        }

        if (!block) {
            if (this.sceneData.nextScene) {
                this.loadScene(this.sceneData.nextScene);
            }
            return;
        }

        // Exactly one portrait is shown at a time. Cassandra stays left; all other speakers appear right.
        if (block.type === 'dialogue') {
            const char = storyLoader.getCharacter(block.speaker);
            const isPlayer = block.speaker === 'cassandra';
            const position = isPlayer ? 'left' : 'right';
            const spritePath = char.portrait || block.sprite || 'assets/images/system_avatar.svg';
            characterBox.classList.toggle('speaker-right', !isPlayer);
            choicesContainer.classList.toggle('speaker-right', !isPlayer);
            this.updateCharacterStage(stage, spritePath, position);
        } else if (block.sprite) {
            this.updateCharacterStage(stage, block.sprite, block.position || 'left');
        }

        if (block.type === 'text') {
            const p = document.createElement('div');
            p.className = 'speech-bubble typing-cursor';
            contentArea.appendChild(p);

            this.typeWriterEffect(p, block.content, () => {
                nextBtn.classList.remove('hidden');
            });

        } else if (block.type === 'dialogue') {
            audioManager.playDialogueSound();
            // Optional dramatic audio is declared per dialogue in story.json.
            // A missing audio property ends the previous dramatic sound immediately.
            audioManager.setDialogueAmbience(block.audio || null);
            const char = storyLoader.getCharacter(block.speaker);
            const isPlayer = block.speaker === 'cassandra';
            characterBox.classList.remove('hidden');

            const speakerLabel = block.badge && block.badge !== '👑' ? block.badge : `${block.badge || '👑'} ${char.name}`;
            const speakerNameEl = document.getElementById('speaker-name');
            speakerNameEl.textContent = speakerLabel;
            speakerNameEl.classList.toggle('speaker-name-right', !isPlayer);

            const dialogueEl = document.getElementById('speaker-dialogue');
            dialogueEl.className = 'speaker-text typing-cursor';
            dialogueEl.style.height = 'auto';
            dialogueEl.style.minHeight = '0';
            dialogueEl.textContent = block.content || '';

            // Measure after the visible dialogue panel has been laid out. A min-height
            // reserves room for every line while still allowing long dialogue to expand.
            requestAnimationFrame(() => {
                const computed = getComputedStyle(dialogueEl);
                const lineHeight = parseFloat(computed.lineHeight) || 24;
                const measuredHeight = Math.ceil(dialogueEl.scrollHeight || dialogueEl.getBoundingClientRect().height);
                dialogueEl.style.minHeight = `${Math.max(lineHeight, measuredHeight)}px`;
                dialogueEl.textContent = '';
                this.typeWriterEffect(dialogueEl, block.content || '', () => {
                    nextBtn.classList.remove('hidden');
                });
            });

            } else if (block.type === 'achievement') {
                const unlocked = playerState.unlockAchievement(block.achievementId || block.title || block.id, block.title);
                if (unlocked) eventManager.showNotification(block.title || 'Achievement unlocked', block.message || 'A new milestone has been recorded.');
                this.autoSave();
                this.currentBlockIndex++;
                this.renderCurrentBlock();
            } else if (block.type === 'notification') {
                eventManager.showNotification(block.title || 'Mission update', block.message || block.content || '');
                this.currentBlockIndex++;
                this.renderCurrentBlock();
            } else if (block.type === 'choice') {
            block.options.forEach((opt, index) => {
                const btn = document.createElement('button');
                
                // First option gets gold gradient primary styling by default (like in your image)
                const isPrimary = index === 0 || opt.sparkle || opt.primary;
                btn.className = `choice-btn ${isPrimary ? 'primary' : ''}`;
                btn.style.setProperty('--choice-delay', `${index * 0.16}s`);
                btn.setAttribute('aria-label', opt.text || 'Continue');
                
                const textContainer = document.createElement('span');
                textContainer.className = 'choice-text-container';
                const title = document.createElement('span');
                title.className = 'choice-title';
                title.textContent = opt.text || 'Continue';
                textContainer.appendChild(title);
                const arrow = document.createElement('span');
                arrow.className = 'choice-arrow';
                arrow.setAttribute('aria-hidden', 'true');
                arrow.textContent = '›';
                btn.append(textContainer, arrow);

                btn.onclick = (e) => {
                    e.stopPropagation();
                    audioManager.playTypeClick();
                    choiceHandler.processChoice(opt, (nextId) => this.loadScene(nextId));
                };
                choicesContainer.appendChild(btn);
            });
        }
    },

    updateCharacterStage(stage, spritePath, position) {
        const resolvedSpritePath = new URL(spritePath, document.baseURI).href;
        const current = stage.querySelector('.character-sprite');
        if (current && current.src === resolvedSpritePath && current.classList.contains(position)) return;
        stage.innerHTML = '';
        const img = document.createElement('img');
        img.src = spritePath;
        img.alt = position === 'left' ? 'Cassandra' : 'Speaking character';
        img.className = `character-sprite ${position}`;
        img.onerror = () => { img.remove(); console.warn(`Character portrait could not load: ${spritePath}`); };
        stage.appendChild(img);
    },

    typeWriterEffect(element, fullText, onComplete) {
        this.isTyping = true;
        this.currentFullText = fullText;
        this.currentTypingElement = element;
        element.textContent = '';

        let charIndex = 0;
        const typeNextChar = () => {
            if (charIndex < fullText.length) {
                element.textContent += fullText.charAt(charIndex);
                charIndex++;
                this.activeTypingTimeout = setTimeout(typeNextChar, 20);
            } else {
                element.classList.remove('typing-cursor');
                this.isTyping = false;
                if (onComplete) onComplete();
            }
        };

        typeNextChar();
    },

    runTerminalBoot(lines, callback) {
        const termScreen = document.getElementById('terminal-screen');
        const termOutput = document.getElementById('terminal-output');
        const inputContainer = document.getElementById('terminal-input-container');
        const input = document.getElementById('terminal-input');
        termScreen.classList.remove('hidden');
        termOutput.textContent = '';
        inputContainer.classList.add('hidden');
        input.value = '';
        input.disabled = false;

        let lineIndex = 0;
        const typeLine = () => {
            if (lineIndex >= lines.length) {
                // Pause before asking the player to authenticate.
                setTimeout(() => {
                    termOutput.textContent += '\nInput passcode: ';
                    termOutput.scrollTop = termOutput.scrollHeight;
                    inputContainer.classList.remove('hidden');
                    input.placeholder = 'Enter passcode';
                    input.focus();
                    const submitPasscode = (event) => {
                        if (event.key !== 'Enter') return;
                        event.preventDefault();
                        const entered = input.value.trim();
                        input.value = '';
                        if (entered !== '1012') {
                            termOutput.textContent += entered + '\nACCESS DENIED: Incorrect passcode. Try again.\nInput passcode: ';
                            termOutput.scrollTop = termOutput.scrollHeight;
                            input.focus();
                            return;
                        }
                        input.removeEventListener('keydown', submitPasscode);
                        input.disabled = true;
                        inputContainer.classList.add('hidden');
                        const afterAuth = [
                            'Identity Verified!',
                            'Loading Mission...',
                            'Objective: Become the most famous Actress.',
                            'Story loading...'
                        ];
                        let authIndex = 0;
                        const typeAuthLine = () => {
                            if (authIndex >= afterAuth.length) {
                                setTimeout(() => {
                                    termScreen.classList.add('hidden');
                                    if (callback) callback();
                                }, 900);
                                return;
                            }
                            const line = afterAuth[authIndex++];
                            let charIndex = 0;
                            const typeChar = () => {
                                if (charIndex < line.length) {
                                    termOutput.textContent += line.charAt(charIndex++);
                                    termOutput.scrollTop = termOutput.scrollHeight;
                                    setTimeout(typeChar, line.charAt(charIndex - 1) === ' ' ? 12 : 22);
                                } else {
                                    termOutput.textContent += '\n';
                                    termOutput.scrollTop = termOutput.scrollHeight;
                                    setTimeout(typeAuthLine, 2000);
                                }
                            };
                            typeChar();
                        };
                        typeAuthLine();
                    };
                    input.addEventListener('keydown', submitPasscode);
                }, 900);
                return;
            }
            const line = lines[lineIndex++];
            let charIndex = 0;
            const typeChar = () => {
                if (charIndex < line.length) {
                    termOutput.textContent += line.charAt(charIndex++);
                    termOutput.scrollTop = termOutput.scrollHeight;
                    setTimeout(typeChar, line.charAt(charIndex - 1) === ' ' ? 12 : 22);
                } else {
                    // A real newline, not the two literal characters backslash+n.
                    termOutput.textContent += '\n';
                    termOutput.scrollTop = termOutput.scrollHeight;
                    setTimeout(typeLine, 2000);
                }
            };
            typeChar();
        };
        typeLine();
    },

    async autoSave() {
        const saveData = {
            sceneId: this.currentSceneId,
            blockIndex: this.currentBlockIndex,
            playerState: playerState.serialize()
        };
        await db.saveGame(saveData);
    }
};