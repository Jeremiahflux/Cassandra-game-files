// Player Career State Management
export const playerState = {
    stats: {
        fame: 0,
        wealth: 0,
        reputation: 50,
        actingSkill: 10,
        controversy: 0,
        rank: 'Unknown Aspirant'
    },
    flags: {},
    achievements: [],
    inventory: [],

    reset() {
        this.stats = {
            fame: 0,
            wealth: 0,
            reputation: 50,
            actingSkill: 10,
            controversy: 0,
            rank: 'Unknown Aspirant'
        };
        this.flags = {};
        this.achievements = [];
        this.inventory = [];
    },

    updateStats(changes) {
        for (const [key, val] of Object.entries(changes)) {
            if (typeof this.stats[key] === 'number') {
                this.stats[key] += val;
                if (key === 'reputation' || key === 'actingSkill') {
                    this.stats[key] = Math.max(0, Math.min(100, this.stats[key]));
                }
                if (this.stats[key] < 0 && key !== 'controversy') this.stats[key] = 0;
            }
        }
        this.recalculateRank();
    },

    recalculateRank() {
        const f = this.stats.fame;
        if (f > 1000000) this.stats.rank = 'Living Legend';
        else if (f > 500000) this.stats.rank = 'Global Icon';
        else if (f > 200000) this.stats.rank = 'Superstar';
        else if (f > 80000) this.stats.rank = 'Recognized Celebrity';
        else if (f > 25000) this.stats.rank = 'Rising Star';
        else if (f > 5000) this.stats.rank = 'Struggling Actress';
        else this.stats.rank = 'Unknown Aspirant';
    },

    setFlag(flagKey, value = true) {
        this.flags[flagKey] = value;
    },

    hasFlag(flagKey) {
        return !!this.flags[flagKey];
    },

    unlockAchievement(id, title) {
        if (!this.achievements.includes(id)) {
            this.achievements.push(id);
            return true;
        }
        return false;
    },

    serialize() {
        return {
            stats: { ...this.stats },
            flags: { ...this.flags },
            achievements: [...this.achievements],
            inventory: [...this.inventory]
        };
    },

    deserialize(data) {
        if (!data) return;
        this.stats = { ...this.stats, ...data.stats };
        this.flags = { ...data.flags };
        this.achievements = [...(data.achievements || [])];
        this.inventory = [...(data.inventory || [])];
    }
};