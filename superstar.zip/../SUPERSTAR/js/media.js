// Cross-fading background manager. All scene assets are local and work offline.
export const mediaManager = {
    fallbackBg: 'assets/images/default_bg.jpg',
    activeLayer: null,
    nextLayer: null,

    ensureLayers() {
        const first = document.getElementById('bg-layer');
        if (!first) return;
        if (!this.activeLayer) this.activeLayer = first;
        if (!this.nextLayer) {
            const next = document.createElement('div');
            next.id = 'bg-layer-next';
            next.className = 'bg-layer bg-layer-next';
            next.style.opacity = '0';
            next.style.pointerEvents = 'none';
            first.parentNode.insertBefore(next, first.nextSibling);
            this.nextLayer = next;
        }
    },

    setBackground(imagePath, cameraMotion = 'none') {
        this.ensureLayers();
        if (!this.activeLayer || !this.nextLayer) return;
        const target = this.nextLayer;
        const source = this.activeLayer;
        const path = imagePath || this.fallbackBg;
        const img = new Image();
        img.onload = () => {
            target.style.backgroundImage = `url("${path}")`;
            target.className = 'bg-layer bg-layer-next';
            const motion = (cameraMotion || 'none').replace('_', '-');
            if (motion) target.classList.add(motion);
            target.style.opacity = '0';
            requestAnimationFrame(() => {
                target.style.opacity = '1';
                source.style.opacity = '0';
                setTimeout(() => {
                    source.style.opacity = '0';
                    const old = this.activeLayer;
                    this.activeLayer = target;
                    this.nextLayer = old;
                }, 1750);
            });
        };
        img.onerror = () => {
            if (path !== this.fallbackBg) this.setBackground(this.fallbackBg, cameraMotion);
            else {
                target.style.backgroundImage = 'linear-gradient(135deg,#0a0b0e,#1a1c24)';
                target.style.opacity = '1';
                source.style.opacity = '0';
            }
        };
        img.src = path;
    }
};
