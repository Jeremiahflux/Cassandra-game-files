// Compact, non-blocking story notifications. Four seconds total, including fly-out.
export const eventManager = {
    showNotification(title, message, duration = 4000) {
        const container = document.getElementById('notification-container');
        if (!container) return;
        const card = document.createElement('div');
        card.className = 'notification-card';
        const heading = document.createElement('div');
        heading.className = 'notification-title';
        heading.textContent = title || 'Story update';
        const body = document.createElement('div');
        body.className = 'notification-msg';
        body.textContent = message || '';
        card.append(heading, body);
        container.appendChild(card);
        const visibleTime = Math.max(0, duration - 350);
        setTimeout(() => {
            card.classList.add('notification-leaving');
            setTimeout(() => card.remove(), 350);
        }, visibleTime);
    }
};
