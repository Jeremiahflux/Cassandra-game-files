// IndexedDB Persistence Wrapper for SUPERSTAR.exe
const DB_NAME = 'SuperstarDB';
const DB_VERSION = 1;

export const db = {
    open() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains('saves')) {
                    db.createObjectStore('saves', { keyPath: 'id' });
                }
                if (!db.objectStoreNames.contains('history')) {
                    db.createObjectStore('history', { keyPath: 'id', autoIncrement: true });
                }
                if (!db.objectStoreNames.contains('settings')) {
                    db.createObjectStore('settings', { keyPath: 'key' });
                }
                if (!db.objectStoreNames.contains('unlocks')) {
                    db.createObjectStore('unlocks', { keyPath: 'id' });
                }
            };
        });
    },

    async saveGame(saveData) {
        const database = await this.open();
        return new Promise((resolve, reject) => {
            const transaction = database.transaction(['saves'], 'readwrite');
            const store = transaction.objectStore('saves');
            const record = { id: 'active_save', ...saveData, timestamp: Date.now() };
            const request = store.put(record);
            request.onsuccess = () => resolve(true);
            request.onerror = () => reject(request.error);
        });
    },

    async loadGame() {
        const database = await this.open();
        return new Promise((resolve, reject) => {
            const transaction = database.transaction(['saves'], 'readonly');
            const store = transaction.objectStore('saves');
            const request = store.get('active_save');
            request.onsuccess = () => resolve(request.result || null);
            request.onerror = () => reject(request.error);
        });
    },

    async clearSave() {
        const database = await this.open();
        return new Promise((resolve, reject) => {
            const transaction = database.transaction(['saves'], 'readwrite');
            const store = transaction.objectStore('saves');
            const request = store.delete('active_save');
            request.onsuccess = () => resolve(true);
            request.onerror = () => reject(request.error);
        });
    },

    async exportSaveJSON() {
        const save = await this.loadGame();
        return JSON.stringify(save, null, 2);
    },

    async importSaveJSON(jsonString) {
        try {
            const data = JSON.parse(jsonString);
            if (!data.sceneId) throw new Error("Invalid save structure");
            await this.saveGame(data);
            return true;
        } catch (err) {
            console.error("Save import failed:", err);
            return false;
        }
    }
};