// Story Loader & Validator
export const storyLoader = {
    storyData: null,
    characters: null,
    endings: null,

    async init() {
        try {
            const [storyRes, charRes, endingRes] = await Promise.all([
                fetch('data/story.json'),
                fetch('data/characters.json'),
                fetch('data/endings.json')
            ]);
            
            this.storyData = await storyRes.json();
            this.characters = await charRes.json();
            this.endings = await endingRes.json();
            
            this.validate();
            return true;
        } catch (err) {
            console.error("Failed to load story assets:", err);
            return false;
        }
    },

    getScene(sceneId) {
        return this.storyData.scenes[sceneId] || null;
    },

    getCharacter(charId) {
        return this.characters[charId] || { name: charId, portrait: '' };
    },

    validate() {
        const scenes = this.storyData.scenes;
        let brokenRefs = [];
        for (const [id, scene] of Object.entries(scenes)) {
            scene.blocks.forEach(block => {
                if (block.type === 'choice') {
                    block.options.forEach(opt => {
                        if (opt.nextScene && !scenes[opt.nextScene]) {
                            brokenRefs.push(`${id} -> ${opt.nextScene}`);
                        }
                    });
                }
                if (block.type === 'transition' && block.nextScene && !scenes[block.nextScene]) {
                    brokenRefs.push(`${id} -> ${block.nextScene}`);
                }
            });
        }
        if (brokenRefs.length > 0) {
            console.warn("⚠️ Story Validator found broken scene references:", brokenRefs);
        } else {
            console.log("✅ Story Validation Passed: All scene links are valid.");
        }
        return brokenRefs;
    }
};